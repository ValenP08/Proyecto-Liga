import express from "express";
import cors from "cors";
import fs from "fs";

const App = express();
const Puerto = 3001;
const ArchivoDatos = "./datos.json";

App.use(cors());
App.use(express.json());

// Datos iniciales por defecto (sin tablas ni modelos relacionales)
const DatosIniciales = {
  Ligas: [
    {
      Id: 1,
      Nombre: "Liga Española 2026",
      Pais: "España",
      Temporada: "2025-2026"
    }
  ],
  Partidos: [
    {
      Id: 1,
      LigaId: 1,
      EquipoLocal: "Real Madrid",
      EscudoLocal: "https://upload.wikimedia.org/wikipedia/en/5/56/Real_Madrid_CF.svg",
      GolesLocal: 2,
      GolesVisita: 1,
      EquipoVisita: "FC Barcelona",
      EscudoVisita: "https://upload.wikimedia.org/wikipedia/en/4/47/FC_Barcelona_%28crest%29.svg",
      Estado: "Finalizado"
    },
    {
      Id: 2,
      LigaId: 1,
      EquipoLocal: "Atlético de Madrid",
      EscudoLocal: "https://upload.wikimedia.org/wikipedia/en/f/f4/Atletico_Madrid_2017_logo.svg",
      GolesLocal: 0,
      GolesVisita: 0,
      EquipoVisita: "Sevilla FC",
      EscudoVisita: "https://upload.wikimedia.org/wikipedia/en/3/3b/Sevilla_FC_logo.svg",
      Estado: "En Vivo - 75'"
    }
  ]
};

// Función auxiliar para leer o crear el archivo JSON
function ObtenerBaseDatos() {
  if (!fs.existsSync(ArchivoDatos)) {
    fs.writeFileSync(ArchivoDatos, JSON.stringify(DatosIniciales, null, 2));
  }
  const Contenido = fs.readFileSync(ArchivoDatos, "utf-8");
  return JSON.parse(Contenido);
}

// Endpoint 1: Obtener información de la liga (/api/v1/ligas/:id)
App.get("/api/v1/ligas/:id", (Req, Res) => {
  const BaseDatos = ObtenerBaseDatos();
  const IdBuscado = Number(Req.params.id);
  const LigaEncontrada = BaseDatos.Ligas.find((Liga) => Liga.Id === IdBuscado);

  if (!LigaEncontrada) {
    return Res.status(404).json({ Mensaje: "Liga no encontrada" });
  }

  Res.json(LigaEncontrada);
});

// Endpoint 2: Obtener lista de partidos (/api/v1/partidos)
App.get("/api/v1/partidos", (Req, Res) => {
  const BaseDatos = ObtenerBaseDatos();
  let ListaFiltrada = BaseDatos.Partidos;

  if (Req.query.ligaId) {
    const IdLiga = Number(Req.query.ligaId);
    ListaFiltrada = ListaFiltrada.filter((Partido) => Partido.LigaId === IdLiga);
  }

  if (Req.query.estado) {
    const EstadoFiltro = Req.query.estado.toLowerCase();
    ListaFiltrada = ListaFiltrada.filter((Partido) =>
      Partido.Estado.toLowerCase().includes(EstadoFiltro)
    );
  }

  Res.json(ListaFiltrada);
});

// Endpoint 3: Obtener detalle de un partido (/api/v1/partidos/:id)
App.get("/api/v1/partidos/:id", (Req, Res) => {
  const BaseDatos = ObtenerBaseDatos();
  const IdPartido = Number(Req.params.id);
  const PartidoEncontrado = BaseDatos.Partidos.find((Partido) => Partido.Id === IdPartido);

  if (!PartidoEncontrado) {
    return Res.status(404).json({ Mensaje: "Partido no encontrado" });
  }

  Res.json(PartidoEncontrado);
});

App.listen(Puerto, () => {
  console.log(`Backend corriendo en http://localhost:${Puerto}`);
});
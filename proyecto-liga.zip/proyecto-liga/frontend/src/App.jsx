import { createResource, Show } from "solid-js";
import { Encabezado } from "./Componentes/Encabezado";
import { ListaPartidos } from "./Componentes/ListaPartidos";

async function ObtenerLiga() {
  const Respuesta = await fetch("http://localhost:3001/api/v1/ligas/1");
  return Respuesta.json();
}

async function ObtenerPartidos() {
  const Respuesta = await fetch("http://localhost:3001/api/v1/partidos?ligaId=1");
  return Respuesta.json();
}

export function App() {
  const [DatosLiga] = createResource(ObtenerLiga);
  const [PartidosLista] = createResource(ObtenerPartidos);

  return (
    <div>
      <Encabezado TituloLiga={DatosLiga()?.Nombre || "Cargando liga..."} />
      <Show
        when={!PartidosLista.loading}
        fallback={<p style={{ "text-align": "center", "margin-top": "2rem" }}>Cargando partidos...</p>}
      >
        <ListaPartidos Partidos={PartidosLista() || []} />
      </Show>
    </div>
  );
}
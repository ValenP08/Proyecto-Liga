export function Encabezado(Props) {
  return (
    <header
      style={{
        "background-color": "var(--FondoTarjeta)",
        "border-bottom": "1px solid var(--Borde)",
        padding: "1.5rem",
        "text-align": "center",
        "box-shadow": "var(--Sombra)"
      }}
    >
      <h1 style={{ margin: "0", "font-size": "1.8rem" }}>{Props.TituloLiga}</h1>
    </header>
  );
}
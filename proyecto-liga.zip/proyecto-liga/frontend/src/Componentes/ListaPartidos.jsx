import { For } from "solid-js";
import { TarjetaPartido } from "./TarjetaPartido";

export function ListaPartidos(Props) {
  return (
    <div style={{ "max-width": "700px", margin: "2rem auto", padding: "0 1rem" }}>
      <For each={Props.Partidos}>
        {(PartidoActual) => <TarjetaPartido DatosPartido={PartidoActual} />}
      </For>
    </div>
  );
}
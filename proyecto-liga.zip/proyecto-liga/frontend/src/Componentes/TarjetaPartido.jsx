export function TarjetaPartido(Props) {
  const Partido = Props.DatosPartido;

  return (
    <div
      style={{
        "background-color": "var(--FondoTarjeta)",
        border: "1px solid var(--Borde)",
        "border-radius": "12px",
        padding: "1.25rem",
        "margin-bottom": "1rem",
        "box-shadow": "var(--Sombra)",
        display: "flex",
        "align-items": "center",
        "justify-content": "space-between"
      }}
    >
      {/* Equipo Local */}
      <div style={{ display: "flex", "align-items": "center", gap: "12px", width: "35%" }}>
        <img
          src={Partido.EscudoLocal}
          alt={Partido.EquipoLocal}
          style={{ width: "48px", height: "48px", "object-fit": "contain" }}
        />
        <span style={{ "font-weight": "600", "font-size": "1rem" }}>{Partido.EquipoLocal}</span>
      </div>

      {/* Marcador y Estado */}
      <div style={{ "text-align": "center", width: "30%" }}>
        <div style={{ "font-size": "1.5rem", "font-weight": "bold", "letter-spacing": "2px" }}>
          {Partido.GolesLocal} - {Partido.GolesVisita}
        </div>
        <div style={{ "font-size": "0.85rem", color: "var(--TextoSecundario)", "margin-top": "4px" }}>
          {Partido.Estado}
        </div>
      </div>

      {/* Equipo Visitante */}
      <div
        style={{
          display: "flex",
          "align-items": "center",
          gap: "12px",
          width: "35%",
          "justify-content": "flex-end"
        }}
      >
        <span style={{ "font-weight": "600", "font-size": "1rem" }}>{Partido.EquipoVisita}</span>
        <img
          src={Partido.EscudoVisita}
          alt={Partido.EquipoVisita}
          style={{ width: "48px", height: "48px", "object-fit": "contain" }}
        />
      </div>
    </div>
  );
}